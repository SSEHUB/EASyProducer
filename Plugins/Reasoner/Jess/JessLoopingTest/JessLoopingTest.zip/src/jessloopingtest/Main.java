package jessloopingtest;

public class Main {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {

		System.out.println("Start Jess Looping ...");
		if (JessLicense.isLicenseValid()) {
			Loop jessLoop = new Loop(1);
			jessLoop.start();
			Thread.sleep(2000);
			jessLoop.stop();
		} else {
			System.err.println("Sorry, your Jess license is expired");
		}
	}
}
