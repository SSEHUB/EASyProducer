package jessloopingtest;
import java.util.Timer;
import java.util.TimerTask;

import jess.JessException;
import jess.Rete;

public class Loop {
	
	boolean licenseValid = true;
	int delay = 0;
	Timer jessTimer;
	Rete engine;

	class JessRunTask extends TimerTask {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try{
				loopingTest();
			} catch (JessException je) {
				System.out.println("Exception...");
				System.err.println(je.getMessage());
			}
			//if the loop would stop, the timer would be canceled.
			//in this test, this should never be reached.
			jessTimer.cancel();
			System.out.println("JessTimer canceled after successful execution!");
		}
		private void loopingTest() throws JessException{
			engine.batch("LoopingTest.clp");
			engine.reset();
			engine.runUntilHalt();
		}
	}
	
	public Loop(int sec){
			delay = sec;
			System.out.println("Create new rete");
			engine = new Rete();
			System.out.println("New rete created");
			jessTimer = new Timer();
	}
	
	public void start() {
		System.out.println("Jess starts in " + delay + " seconds");
		jessTimer.schedule(new JessRunTask(), delay*1000);
	}
	
	public void stop() {
		System.out.println("Jess will stop...");
		try {
			engine.halt();
		} catch (JessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jessTimer.cancel();
		System.out.println("Jess stopped successfully from outside!");
	}
}
