package net.ssehub.easy.examples.carshop;

/**
 * Data transfer object that stores the relevant information of a car description.
 * @author El-Sharkawy
 *
 */
public class CarInformation {

	public String name;
	public String description;
	public String engineType;
	public int minHorsePower;
	public int maxHorsePower;
}
