package net.ssehub.easy.examples.carshop;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/**
 * An XML parser to load car descriptions from XML files.
 * The files should have the following format:
 * <pre>{@code
 * <car name="<<<Name of the car>>>">
 *  <engine type="<<<Gasoline | Diesel | Eletric>>>" min_hp="<<<A number>>>" max_hp="<<<A number>>>"/>
 *  <description>
 *  <<<A description text>>>.
 *  </description>
 *</car>
 *}
 *</pre>
 * @author El-Sharkawy
 *
 */
public class InformationPaser {
	
	/**
	 * Avoids instantiation.
	 */
	private InformationPaser() {}

	/**
	 * Parsed an XML document containing a car description.
	 * @param xmlFile An XML file containing a car description.
	 * @return The parsed content.
	 */
	public static CarInformation parse(File xmlFile) throws ParserConfigurationException, SAXException, IOException {
		CarInformation result = new CarInformation();
		
		DocumentBuilderFactory factory =
		DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(xmlFile);
		
		// Root node
		Element root = doc.getDocumentElement();
		result.name = root.getAttribute("name");
		
		// Engine
		Element engineNode = (Element) doc.getElementsByTagName("engine").item(0);
		result.engineType = engineNode.getAttribute("type");
		result.minHorsePower = Integer.valueOf(engineNode.getAttribute("min_hp"));
		result.maxHorsePower = Integer.valueOf(engineNode.getAttribute("max_hp"));
		
		// Description
		Element descriptionNode = (Element) doc.getElementsByTagName("description").item(0);
		result.description = descriptionNode.getTextContent().trim();
		
		return result;
	}
}
