package net.ssehub.easy.examples.carshop;

import java.awt.BorderLayout;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class ShopWindow extends JFrame implements ActionListener {

	private static final String TITLE = "Car Shop";
	private static final int WINDOW_WIDTH = 800;
	private static final int WINDOW_HEIGHT = 640;
	
    /** 
    * Generated.
    */
    private static final long serialVersionUID = -7795029161240905870L;
    
    private JLabel carPreview;
	private JTextPane  carDescription;
	private JButton prevButton;
	private JButton nextButton;
	private StyledDocument doc;
	private Style titleStyle;
	private Style boldStyle;
	private Style normalStyle;
	
	private File[] cars = new File("cars").listFiles();
	private int index = 0;
	
    /** 
    * Creates a window that displays all selected cars (descriptions + pictures).
    */
    public ShopWindow() throws IOException {
    	super(TITLE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ReflectiveOperationException | UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
		
		setLayout(new BorderLayout());
		
		// Create content view: Picture + Description
		JPanel contentPanel = new JPanel();
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new GridLayout(1, 2, 10, 10));
		carPreview = new JLabel();
		contentPanel.add(carPreview);
		carDescription = new JTextPane();
		carDescription.setEditable(false);
		contentPanel.add(carDescription);
		
		// Configure styles
		doc = carDescription.getStyledDocument();
		titleStyle = doc.addStyle("TITLE", null);
		StyleConstants.setBold(titleStyle, true);
		StyleConstants.setFontSize(titleStyle, 18);
		boldStyle = doc.addStyle("BOLD", null);
		StyleConstants.setFontSize(boldStyle, 16);
		StyleConstants.setBold(boldStyle, true);
		normalStyle = doc.addStyle("NORMAL", null);
		StyleConstants.setBold(normalStyle, false);
		StyleConstants.setFontSize(normalStyle, 16);
		
		// Create Menu
		JPanel menuPanel = new JPanel();
		getContentPane().add(menuPanel, BorderLayout.SOUTH);
		prevButton = new JButton();
		prevButton.setIcon(loadScaledImage("img/previous.png", 50));
		prevButton.addActionListener(this);
		nextButton = new JButton();
		nextButton.setIcon(loadScaledImage("img/next.png", 50));
		nextButton.addActionListener(this);
		menuPanel.add(prevButton);
		menuPanel.add(nextButton);
        
        if (0 == cars.length) {
            cars = new File[]{new File("img/404.png")};
        }
        
        // Display first car
 		actionPerformed(null);
 		
        // Centers the frame on the screen
        setLocationRelativeTo(null);
 		setVisible(true);
    }
    /** 
    * Formats and sets the description test of the car.
    * @param description A parsed description information of the car to be displayed.
    */
    private void setDescription(CarInformation description) {
        try {
            doc.remove(0, doc.getLength());
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
        
        if (null != description) {
            try {
                doc.insertString(0, description.name + "\n", titleStyle);
                if (null != description.engineType) {
                    doc.insertString(doc.getLength(), "\u2022 Combustion Type: ", boldStyle);
                    doc.insertString(doc.getLength(), description.engineType + "\n", normalStyle);
                }
                if (0 != description.minHorsePower) {
                    doc.insertString(doc.getLength(), "\u2022 Min. Horsepower: ", boldStyle);
                    doc.insertString(doc.getLength(), description.minHorsePower + "\n", normalStyle);
                }
                if (0 != description.maxHorsePower) {
                    doc.insertString(doc.getLength(), "\u2022 Max. Horsepower: ", boldStyle);
                    doc.insertString(doc.getLength(), description.maxHorsePower + "\n", normalStyle);
                }
                if (null != description.description) {
                    doc.insertString(doc.getLength(), "Further Details:\n", boldStyle);
                    doc.insertString(doc.getLength(), description.description, normalStyle);
                }
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        }
    }
    
    /** 
    * Loads a scaled image from the specified location.
    * @param path The path to an image to load.
    * @param desiredWidth The desired width of the image (height will be scaled accordantly).
    * @return The loaded image.
    */
    private ImageIcon loadScaledImage(String path, int desiredWidth) throws IOException {
    	// Reads the Image
		File imageFile = new File(path);
		BufferedImage img = ImageIO.read(imageFile);
		
		// Computes scale factor
		int width = img.getWidth(null);
		double scale = ((double) width) / desiredWidth;
		width = (int) (width / scale);
		int height = (int) (img.getHeight(null) / scale);
		
		// Re-scales image
		BufferedImage bufferedImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = bufferedImg.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img, 0, 0, width, height, null);
        g2.dispose();
		
		return new ImageIcon(bufferedImg);
    }
    
    /** 
    * Handles button events.
    */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (null != e) {
            if (e.getSource() == nextButton) {
                index += 1;
            }
            if (e.getSource() == prevButton) {
                index -= 1;
            }
        }
        
        if (index < 0) {
        	index = cars.length - 1;
        } else {
        	index %= cars.length;
        }
        
        ImageIcon icon = null;
		try {
			icon = loadScaledImage(cars[index].getPath(), 350);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (null != icon) {
			carPreview.setIcon(icon);
		}
		
        String fileName = cars[index].getName().substring(0, cars[index].getName().length() - 4);
        if ("404".equals(fileName)) {
            CarInformation description = new CarInformation();
            description.name = "Error: No car selected";
            setDescription(description);
        } else {
            File descriptionFile = new File("desc/" + fileName + ".xml");
            try {
                CarInformation description = InformationPaser.parse(descriptionFile);
                setDescription(description);
            } catch (ParserConfigurationException | SAXException | IOException e1) {
                setDescription(null);
            }
        }
        
        repaint();
    }
    
    /** 
    * Starts the application.
    * @param args Will be ignored.
    */
    public static void main(String[] args) throws IOException {
        new ShopWindow();
    }
}
