import factory.IRandom;
import factory.RandomFactory;

public class Main {

	public static void main(String[] args) {
		IRandom generator = RandomFactory.generateRandomGenerator();
		
		System.out.println("Next value is: " + generator.nextRandomValue());

	}

}
