package factory;

public interface IRandom {
	
	/**
	 * Creates the next random value.
	 * @return A random value;
	 */
	public Object nextRandomValue();

}
