package factory;

class Deck implements IRandom {
	
	private static final String[] CARDS = {"Skip turn", "Extra turn", "..."};
	
	Deck() {}

	@Override
	public Object nextRandomValue() {
		int index = (int) (Math.random() * CARDS.length);
		return CARDS[index];
	}

}
