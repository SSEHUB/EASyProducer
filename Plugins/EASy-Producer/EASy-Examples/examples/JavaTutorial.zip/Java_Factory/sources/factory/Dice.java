package factory;

class Dice implements IRandom {
	
	private int pips;
	
	Dice() {
		this(6);
	}
	
	Dice(int pips) {
		this.pips = pips;
	}

	@Override
	public Object nextRandomValue() {
		return (int) (Math.random() * pips) + 1;
	}

}
