package factory;

public class RandomFactory {
	
	/**
	 * Returns a random generator, depending on the instantiation.
	 * @return The same class of random generator.
	 */
	public static IRandom generateRandomGenerator() {
		IRandom generator = null;
		
		// Creates dice with 6 pips
		generator = new Dice();
		
		// Creates cards deck
		generator = new Deck();
		
		return generator;
	}

}
