
public class HelloWorld {

	/**
	 * Will be instantiated.
	 * @return
	 */
	public static String createMessage() {
		return "$message";
	}
	
	/**
	 * Only for demonstration.
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(createMessage());
	}

}
