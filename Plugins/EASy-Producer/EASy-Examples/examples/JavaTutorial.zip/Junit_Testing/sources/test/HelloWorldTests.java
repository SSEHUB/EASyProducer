import org.junit.Assert;
import org.junit.Test;

public class HelloWorldTests {

	@Test
	public void testCreateMessage() {
		// Test correct message
		Assert.assertEquals("Method \"HelloWorld.createMessage()\" "
			+ "was instantiated with wrong value",
			"$message",
			HelloWorld.createMessage());
		
		// Test that it was instantiated at all
		Assert.assertNotEquals("Method \"HelloWorld.createMessage()\" "
			+ "was NOT instantiated.",
			"\u0024message",
			HelloWorld.createMessage());
	}

}
