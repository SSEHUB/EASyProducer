Self instantiating project:
- Open product line editor
- Dervivation not needed!
- Fill value for floors (and also other variables)
- Validate/propagate
- Freeze
- Instantiate