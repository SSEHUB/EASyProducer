Command processor demo product line: EASyDemoCommandsFile

Instantiates variabilities by removing unnecessary classes.

Main class: io.ssehub.easy.demo.command.file.Main