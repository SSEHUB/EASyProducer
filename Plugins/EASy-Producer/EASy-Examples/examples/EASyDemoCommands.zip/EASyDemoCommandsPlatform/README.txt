Command processor demo product line: EASyDemoCommandsPlatform

Implements the basic command platform with two mandatory and some (not used) optional commands. 

Main class: io.ssehub.easy.demo.command.Processor