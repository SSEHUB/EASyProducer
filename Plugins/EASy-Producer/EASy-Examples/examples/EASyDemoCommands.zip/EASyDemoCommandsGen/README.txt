Command processor demo product line: EASyDemoCommandsGen

Instantiates variabilities by generating artifacts. Here, we generate a properties file (startup time variability) as well 
as integrating glue code for an unlimited number of simple commands, which just provide the execute method.

Main class: io.ssehub.easy.demo.command.gen.Main
Additional simple commands: io.ssehub.easy.demo.command.gen.additional