Command processor demo product line: EASyDemoCommandsConstants

Instantiates variabilities by directly modifying code constants and relying on condition-on-constant.

Main class: io.ssehub.easy.demo.command.constants.Main