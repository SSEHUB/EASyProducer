package io.ssehub.easy.demo.command.genStatic;

import javax.annotation.Generated;

/**
 * Represents the program configuration as Java constants.
 * 
 * @author SSE@SUH
 */
@Generated(value = { "EASy-Producer" })
public class Constants {

	static final String APP_NAME = "";
	static final boolean hasAddCommand = false;
	static final boolean hasSubCommand = false;
	static final boolean hasPrintCommand = false;
	
}
