Command processor demo product line: EASyDemoCommandsVelocity

Instantiates variabilities utilizing Apache velocity as preprocessor.

Main class: io.ssehub.easy.demo.command.velocity.Main