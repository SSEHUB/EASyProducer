Command processor demo product line: EASyDemoCommandsGenStatic

Instantiates variabilities generating a constants class.

Main class: io.ssehub.easy.demo.command.genStatic.Main