package io.ssehub.easy.demo.tree;

public class SportMode {

}
