package io.ssehub.easy.demo.tree;

public class Engine {
	
	public static final int HORSEPOWER = 0;

}
