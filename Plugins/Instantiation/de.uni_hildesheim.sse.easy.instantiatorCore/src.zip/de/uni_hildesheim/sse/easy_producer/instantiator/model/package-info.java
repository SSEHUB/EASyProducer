/**
 * This package holds classes related to the instantiator model for the EASy-Producer.
 */
package de.uni_hildesheim.sse.easy_producer.instantiator.model;