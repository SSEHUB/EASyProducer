/**
 * This package contains the core of all instantiators, which can be used in EASy.
 */
package de.uni_hildesheim.sse.easy_producer.instantiator;