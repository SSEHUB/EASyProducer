/**
 * Implements the a readable interface to IVML/EAsY. Specific interfaces
 * may add writable functionality.
 */
package de.uni_hildesheim.sse.integration.common;
