package de.uni_hildesheim.sse.integration.common;

/**
 * Classifies elements of an IVML model.
 * 
 * @author Holger Eichelberger
 */
public interface IModelElement {

}
